from django.apps import AppConfig


class LangappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'langapp'
