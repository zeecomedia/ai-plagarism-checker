# AI CONTENT PLAGIARISM CHECKER BUILT WITH DJANGO AND PYTHON
## HOW TO RUN

## pip install -r requirements.txt

## python manage.py runserver
